const setupGuild = require('./func/setup')

module.exports = {
    setupGuild
}