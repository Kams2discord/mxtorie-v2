const sanctions = require('./func/sanctions')

module.exports = {
    sanctions
}